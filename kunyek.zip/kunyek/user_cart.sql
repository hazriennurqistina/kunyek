-- Create a table to store user cart data
CREATE TABLE user_cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT, -- Replace with your user identifier, if applicable
    cart_data TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
