CREATE TABLE sales (
    id INT AUTO_INCREMENT PRIMARY KEY,
    menu_id INT,
    quantity INT,
    price DOUBLE,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (menu_id) REFERENCES menu_items(id)
);
