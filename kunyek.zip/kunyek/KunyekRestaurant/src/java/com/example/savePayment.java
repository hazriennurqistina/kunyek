/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.example;

/**
 *
 * @author Huawei
 */
import com.example.Payment;
import com.util.DBConnection;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class savePayment {
    private static final String INSERT_PAYMENT_SQL = "INSERT INTO payments (payment_id, amount_paid, payment_date, payment_method, address, bank_type) " +
                                                     "VALUES (?, ?, ?, ?, ?, ?)";

    public void savePayment(Payment payment) {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(INSERT_PAYMENT_SQL)) {

            stmt.setString(1, payment.getPaymentId());
            stmt.setBigDecimal(2, payment.getAmountPaid());
            stmt.setDate(3, new java.sql.Date(payment.getPaymentDate().getTime()));
            stmt.setString(4, payment.getPaymentMethod());
            stmt.setString(5, payment.getAddress());
            stmt.setString(6, payment.getBankType());

            int rowsInserted = stmt.executeUpdate();
            if (rowsInserted > 0) {
                System.out.println("A new payment was inserted successfully!");
            }

        } catch (SQLException e) {
            e.printStackTrace(); // Handle or log the exception as needed
        }
    }
}
