package com.controller;

import com.dao.DatabaseConnection;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String phoneNo = request.getParameter("phoneNo");
        String address = request.getParameter("address");
        String state = request.getParameter("state");
        String email = request.getParameter("email");
        String password = request.getParameter("password");

        String query = "INSERT INTO users (username, f_name, l_name, no_phone, address, state, email, password) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setString(1, username);
            statement.setString(2, firstName);
            statement.setString(3, lastName);
            statement.setString(4, phoneNo);
            statement.setString(5, address);
            statement.setString(6, state);
            statement.setString(7, email);
            statement.setString(8, password);

            int result = statement.executeUpdate();

            if (result > 0) {
                // Registration successful
                request.setAttribute("message", "success");
                request.setAttribute("username", username);
                request.getRequestDispatcher("/register.jsp").forward(request, response);
            } else {
                // Registration failed
                response.sendRedirect("register.jsp?message=failure");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.sendRedirect("register.jsp?message=error");
        }
    }
}
