package com.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import com.util.DBConnection;
import static java.lang.System.out;

//@WebServlet("/EditOrderServlet")
public class EditOrderServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        int orderId = Integer.parseInt(request.getParameter("id"));
        String customerName = request.getParameter("customerName");
        String orderDate = request.getParameter("orderDate");
        String orderDetails = request.getParameter("orderDetails");
        String orderStatus = request.getParameter("orderStatus");

        try (Connection con = DBConnection.getConnection()) {
            String query = "UPDATE orders SET order_date = ?, order_details = ?, order_status = ? WHERE id = ?";
            PreparedStatement pstmt = con.prepareStatement(query);
            pstmt.setString(1, orderDate);
            pstmt.setString(2, orderDetails);
            pstmt.setString(3, orderStatus);
            pstmt.setInt(4, orderId);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
            out.print(e.getMessage());
        }

        response.sendRedirect("DeliveryListVendor.jsp");
    }
}