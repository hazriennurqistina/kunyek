package com.controller;



import com.util.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

//@WebServlet("/CreateOrderServlet")
public class CreateOrderServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String orderDate = request.getParameter("orderDate");
        String orderDetails = request.getParameter("orderDetails");
        String orderStatus = request.getParameter("orderStatus");

        Connection con = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try {
            con = DBConnection.getConnection();

            // First, retrieve the userID based on the username
            String userQuery = "SELECT userID FROM users WHERE username = ?";
            pstmt = con.prepareStatement(userQuery);
            pstmt.setString(1, username);
            rs = pstmt.executeQuery();

            if (rs.next()) {
                int userID = rs.getInt("userID");

                // Now, insert the order with the retrieved userID
                String orderQuery = "INSERT INTO orders (userID, order_date, order_details, order_status) VALUES (?, ?, ?, ?)";
                pstmt = con.prepareStatement(orderQuery);
                pstmt.setInt(1, userID);
                pstmt.setString(2, orderDate);
                pstmt.setString(3, orderDetails);
                pstmt.setString(4, orderStatus);
                pstmt.executeUpdate();

                response.sendRedirect("DeliveryListVendor.jsp");
            } else {
                response.getWriter().write("Error: User not found. Please use the correct username");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().write("Error creating order: " + e.getMessage());
        } finally {
            try {
                if (rs != null) rs.close();
                if (pstmt != null) pstmt.close();
                if (con != null) con.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}