package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//@WebServlet("/UpdateProfileServlet")
public class UpdateProfileServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Retrieve form parameters
        String firstName = request.getParameter("firstName");
        String lastName = request.getParameter("lastName");
        String phoneNo = request.getParameter("phoneNo");
        String address = request.getParameter("address");
        String email = request.getParameter("email");

        // Assuming username is retrieved from session
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("username");

        // Database connection parameters
        String jdbcUrl = "jdbc:mysql://localhost:3306/kunyek";
        String dbUser = "root";
        String dbPassword = "admin";

        Connection con = null;
        PreparedStatement ps = null;

        try {
            // Load JDBC driver
            Class.forName("com.mysql.cj.jdbc.Driver");

            // Establish connection
            con = DriverManager.getConnection(jdbcUrl, dbUser, dbPassword);

            // Update query
            String updateQuery = "UPDATE users SET f_name=?, l_name=?, no_phone=?, address=?, email=? WHERE username=?";
            ps = con.prepareStatement(updateQuery);
            ps.setString(1, firstName);
            ps.setString(2, lastName);
            ps.setString(3, phoneNo);
            ps.setString(4, address);
            ps.setString(5, email);
            ps.setString(6, username);

            // Execute update
            int rowsUpdated = ps.executeUpdate();

            if (rowsUpdated > 0) {
                // Update successful
                String successMessage = "Your profile has been successfully updated. We appreciate your effort in keeping it up to date.";
                request.setAttribute("message", successMessage);
                request.getRequestDispatcher("/profile.jsp").forward(request, response);
            } else {
                // No rows updated
                String errorMessage = "Failed to update profile. Please try again.";
                request.setAttribute("error", errorMessage);
                request.getRequestDispatcher("/profile.jsp").forward(request, response);
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            out.println("<div class='alert alert-danger' role='alert'>Database error: " + e.getMessage() + "</div>");
        } finally {
            // Close resources
            try {
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
