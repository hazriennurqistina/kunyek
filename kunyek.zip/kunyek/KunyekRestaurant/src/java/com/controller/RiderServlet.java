package com.controller;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
import com.util.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

//@WebServlet("/RiderServlet")
public class RiderServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String riderId = request.getParameter("riderId");
        String fullName = request.getParameter("fullName");
        String phone = request.getParameter("phone");
        String email = request.getParameter("email");
        String vehicleType = request.getParameter("vehicleType");
        String vehicleNumber = request.getParameter("vehicleNumber"); 

        try (Connection con = DBConnection.getConnection()) { // Sini connect to database
            String query = "INSERT INTO riders (rider_id, full_name, phone, email, vehicle_type, vehicle_number) VALUES (?, ?, ?, ?, ?, ?)"; 
            PreparedStatement pstmt = con.prepareStatement(query);
            pstmt.setString(1, riderId);
            pstmt.setString(2, fullName);
            pstmt.setString(3, phone);
            pstmt.setString(4, email);
            pstmt.setString(5, vehicleType);
            pstmt.setString(6, vehicleNumber);
            pstmt.executeUpdate();


            request.getRequestDispatcher("confirmation.jsp").forward(request, response); 
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().write("Error creating order: " + e.getMessage());
        }
    }
}