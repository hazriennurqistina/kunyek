/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package com.controller;

import com.example.Payment;
import java.io.IOException;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//@WebServlet("/submitPaymentServlet")
public class submitPaymentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response, Date paymentDate) throws ServletException, IOException {
        // Retrieve form parameters
        String paymentId = request.getParameter("paymentId");
        String amountPaidStr = request.getParameter("amountPaid");
        String paymentDateStr = request.getParameter("paymentDate");
        String paymentMethod = request.getParameter("paymentMethod");
        String address = request.getParameter("address");
        String bankType = request.getParameter("bankType");
       
        // Parse amount paid
        BigDecimal amountPaid = new BigDecimal(amountPaidStr);

        // Create Payment object and set attributes
        Payment payment = new Payment();
        payment.setPaymentId(paymentId);
        payment.setAmountPaid(amountPaid);
        payment.setPaymentDate(paymentDate);
        payment.setPaymentMethod(paymentMethod);
        payment.setAddress(address);
        payment.setBankType(bankType);

        // Set payment object as a request attribute
        request.setAttribute("payment", payment);

        // Forward to receipt.jsp
        request.getRequestDispatcher("/receipt.jsp").forward(request, response);
    }
}
