package com.controller;

import com.util.DBConnection;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

//@WebServlet("/PaymentServlet")
public class PaymentServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        String amountPaidStr = request.getParameter("amountPaid");
        String paymentDateStr = request.getParameter("paymentDate");
        String paymentMethod = request.getParameter("paymentMethod");
        String address = request.getParameter("address");
        String bankType = request.getParameter("bankType"); 

        try (Connection con = DBConnection.getConnection()) { // Sini connect to database
            String query = "INSERT INTO payments (amount_paid, payment_date, payment_method, address, bank_type) VALUES (?, ?, ?, ?, ?)"; // tukar apa yang patut orders tu ganti dengan table kau 
            PreparedStatement pstmt = con.prepareStatement(query);
            pstmt.setString(1, amountPaidStr);
            pstmt.setString(2, paymentDateStr);
            pstmt.setString(3, paymentMethod);
            pstmt.setString(4, address);
            pstmt.setString(5, bankType);
            pstmt.executeUpdate();


            response.sendRedirect("receipt.jsp"); 
        } catch (SQLException e) {
            e.printStackTrace();
            response.getWriter().write("Error creating order: " + e.getMessage());
        }
    }
}