/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */




function deleteOrder(orderId) {
    if (confirm("Are you sure you want to delete this order?")) {
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "DeleteOrderServlet", true);
        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
        xhr.onreadystatechange = function () {
            if (xhr.readyState == 4) { // Check if the request is complete
                if (xhr.status == 200) { // Check if the response status is 200 (OK)
                    window.location.reload(); // Reload the page if deletion was successful
                } else {
                    alert("Please refresh the website to complete the deletion process"); // Alert if deletion failed
                }
            }
        };
        xhr.send("id=" + orderId); // Send the order ID to the servlet
    }
}

            function changeOrderStatusVendor(orderId, currentStatus) {
                if (currentStatus === "PREPARED"  currentStatus === "DELIVERING"  currentStatus === "DELIVERED") {
                    alert("Cannot change the status of the order at this point.");
                } else if (currentStatus === "PREPARING") {
                    if (confirm("Are you sure that the food is prepared and ready for delivery?")) {
                        var xhr = new XMLHttpRequest();
                        xhr.open("POST", "ChangeOrderStatusServlet", true);
                        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                        xhr.onreadystatechange = function () {
                            if (xhr.readyState == 4 && xhr.status == 200) {
                                // Refresh the page to show updated status
                                window.location.reload();
                            }
                        };
                        xhr.send("id=" + orderId + "&newStatus=PREPARED");
                    }
                } else{
                    alert("ERROR Please consult the user manual");
                }
            }
            function changeOrderStatusRider(orderId, currentStatus) {
            switch (currentStatus) {
                case "PREPARED":
                    if (confirm("Are you sure that the food is prepared and ready for delivery?")) {
                        var xhr = new XMLHttpRequest();
                        xhr.open("POST", "ChangeOrderStatusServlet", true);
                        xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                        xhr.onreadystatechange = function () {
                            if (xhr.readyState == 4 && xhr.status == 200) {
                                // Refresh the page to show updated status
                                window.location.reload();
                            }
                        };
                        xhr.send("id=" + orderId + "&newStatus=DELIVERING");
                            } else {
                                alert("There was an error to change the status");
                            }
                            break;
        case "DELIVERING":
            if(confirm("Are you sure that the food is delivered to the customer?")){
                var xhr = new XMLHttpRequest();
                xhr.open("POST", "ChangeOrderStatusServlet", true);
                xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                xhr.onreadystatechange = function () {
                    if (xhr.readyState == 4 && xhr.status == 200) {
                        // Refresh the page to show updated status
                        window.location.reload();
                    }
                };
                xhr.send("id=" + orderId + "&newStatus=DELIVERED");
            }