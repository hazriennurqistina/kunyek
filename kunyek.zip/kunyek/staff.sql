

CREATE TABLE staff (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(100) NOT NULL,
    fullname VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    phoneNumber VARCHAR(20) NOT NULL,
    role ENUM('rider', 'manager') NOT NULL,
    streetName VARCHAR(100),
    postcode VARCHAR(10),
    city VARCHAR(50),
    state VARCHAR(50),
    profilePhoto LONGBLOB
);

-- Inserting manager record
INSERT INTO staff (username, password, fullname, email, phoneNumber, role)
VALUES ('manager', '12345', 'Manager Name', 'manager@gmail.com', '123456789', 'manager');


