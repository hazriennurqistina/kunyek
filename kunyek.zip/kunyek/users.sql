

CREATE TABLE  users (
    userID INT(10) AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(30) UNIQUE NOT NULL,
    f_name VARCHAR(30),
    l_name VARCHAR(30),
    no_phone VARCHAR(30),
    address VARCHAR(30),
    state VARCHAR(30),
    email VARCHAR(30) UNIQUE NOT NULL,
    password VARCHAR(10) NOT NULL
);
