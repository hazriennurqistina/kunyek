

CREATE TABLE orders(
 id int AUTO_INCREMENT PRIMARY key,
    order_date datetime DEFAULT CURRENT_TIMESTAMP,
    order_details varchar(255),
    order_status varchar(255) default "PREPARING",
    userID int, 
    CONSTRAINT FK_userID FOREIGN KEY (userID)REFERENCES users(userID)
)