CREATE TABLE menu_items (
    id INT AUTO_INCREMENT PRIMARY KEY,
    picture VARCHAR(255),
    name VARCHAR(100),
    description TEXT,
    price DECIMAL(10, 2)
);

